# Swasthya AI Assignment
## To run this project 

### 1. Clone it using "https://github.com/SBAhire/swasthya_ai_assignment.git"

### 2. Install requirements using "pip install -r requirements.txt"

### 3. Start django server using "python manage.py runserver" on windows or "python3 manage.py runserver" on linux

### 4. You can see all blogs and comments using '/blogs' and '/comments' endpoints and can use the same endpoints for posting the blog and comment one at a time




